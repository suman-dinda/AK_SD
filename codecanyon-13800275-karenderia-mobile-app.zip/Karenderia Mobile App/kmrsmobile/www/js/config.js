var krms_config ={		
	'ApiUrl':"",				
	'DialogDefaultTitle':"KMRS",	
	'APIHasKey':"",
	'debug': false
};
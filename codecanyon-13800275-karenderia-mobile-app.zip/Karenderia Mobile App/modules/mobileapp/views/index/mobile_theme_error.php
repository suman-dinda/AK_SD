<div class="header_mobile"> 
 <img src="<?php echo $logo?>" />
</div>

<div class="mobile_body">
 <h2><?php echo AddonMobileApp::t("Error")?></h2>
 <p><?php echo $message?></p>
</div>
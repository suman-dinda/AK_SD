<div class="header_mobile"> 
 <h4><?php echo t("Receipt")?></h4>
 <img src="<?php echo $logo?>" />
</div>

<div class="mobile_body">
 <h2><?php echo AddonMobileApp::t("Thank You")?></h2>
 <p><?php echo $message?></p>
 <i class="fa fa-check-circle check"></i>
</div>
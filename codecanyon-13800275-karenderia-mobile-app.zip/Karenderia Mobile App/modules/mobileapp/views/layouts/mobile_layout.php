<?php $this->renderPartial('/layouts/header');?>

<body>
<?php echo $content?> 
</body>

<?php $this->renderPartial('/layouts/footer');?>